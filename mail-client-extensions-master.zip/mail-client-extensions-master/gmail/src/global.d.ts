declare let global: any;
type Card = any;
type ActionEvent = any;
type CardSection = any;
type Button = any;
type GmailAttachment = any;
